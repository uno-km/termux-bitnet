# termux-bitnet

> **Single C++ Core & Multi-Language Thin Gateways (Python SDK + Node.js npm) for 1.58-bit (i2_s) BitNet On-Device Inference on Android Termux & ARM64.**

[![License](https://img.shields.io/badge/License-Apache_2.0-blue.svg)](https://opensource.org/licenses/Apache-2.0)
[![Architecture](https://img.shields.io/badge/Core-Native%20C++17%20|%20NEON%20|%20DotProd-brightgreen.svg)]()
[![Python SDK](https://img.shields.io/badge/Gateway-pip%20install%20termux--bitnet-blue.svg)]()
[![Node.js SDK](https://img.shields.io/badge/Gateway-npm%20install%20termux--bitnet-red.svg)]()
[![Platform](https://img.shields.io/badge/Platform-Android%20Termux%20|%20PRoot%20|%20Linux-orange.svg)]()

---

## 1. 아키텍처 철학: "Single C++ Core, Dual Thin Gateways"

`termux-bitnet`은 **"연산과 텐서 제어의 모든 핵심(Heavy Lifting)은 오직 순수 C++ 단 한 곳에서만 수행하고, Python(`pip`)과 Node.js(`npm`)는 제로 오버헤드로 C++ 엔진에 진입하는 경량 입구(Thin Gateway / FFI Boundary) 역할만 수행한다"**는 글로벌 표준 오픈소스 AI 엔진 설계 원칙을 철저히 준수합니다.

```mermaid
graph TD
    subgraph Gateways ["Multi-Language Thin Gateways (Lightweight Entry Points)"]
        G1["Python Gateway<br/><code>pip install termux-bitnet</code><br/>(ctypes Zero-Copy FFI)"]
        G2["Node.js / TS Gateway<br/><code>npm install termux-bitnet</code><br/>(Native CLI / IPC)"]
        G3["Native CLI<br/><code>termux-bitnet-cli</code>"]
    end

    subgraph Boundary ["Strict C ABI Boundary (include/termux_bitnet.h)"]
        ABI["bitnet_init() | bitnet_eval() | bitnet_generate_stream() | bitnet_free()"]
    end

    subgraph Core ["Single High-Performance C++ Core (libtermux_bitnet.so)"]
        K1["ARM64 NEON + DotProd Accel (vdotq_s32)"]
        K2["ARM64 NEON + FMA Fallback (vmlal_s8)"]
        K3["QK=128 32-Stride Interleaved Scalar Fallback"]
        KV["KV Cache & Top-P / Temperature Sampler"]
    end

    G1 --> ABI
    G2 --> ABI
    G3 --> ABI
    ABI --> Core
```

---

---

## 2. 검증된 비트넷 모델 레지스트리 (Verified Model Registry)

`termux-bitnet`은 Hugging Face 상의 공식/커뮤니티 1.58-bit GGUF 모델을 지원하며, 내장 다운로더(`download`)를 통해 원터치로 캐싱 및 구동할 수 있습니다:

| Alias | 원본 저장소 및 모델 파일 | 파라미터 / 용량 | 특징 |
|---|---|---|---|
| `bitnet-2b` | `microsoft/bitnet-b1.58-2B-4T-gguf` | 2.4B / **1.13 GB** | Microsoft 공식 1.58-bit 플래그십 (모바일 권장) |
| `bitnet-large` | `RichardErkhov/1bitLLM_-_bitnet_b1_58-large-gguf` | 0.7B / **404 MB** | 저사양 모바일/Termux 기기용 초경량 엔진 |
| `bitnet-3b` | `Green-Sky/bitnet_b1_58-3B-GGUF` | 3.3B / **730 MB** | 대용량 고정밀 온디바이스 모델 |
| `bitnet-3b-q4` | `RichardErkhov/1bitLLM_-_bitnet_b1_58-3B-gguf` | 3.3B / **1.83 GB** | Q4 양자화 고성능 3B 모델 |

```bash
# 모델 원터치 다운로드 (이어받기 지원)
termux-bitnet download bitnet-2b
```

---

## 3. 빠른 시작 (Quick Start)

### 3.1 Python Gateway (`pip`)

```bash
# 설치
pip install termux-bitnet

# 실행 (풀 파라미터 제어)
termux-bitnet run -m ~/.cache/termux-bitnet/models/bitnet-2b-ggml-model-i2_s.gguf \
  -p "The capital of France is" \
  -t 8 -c 2048 -n 128 --temp 0.7 --top-p 0.95 --top-k 40 --repeat-penalty 1.15
```

```python
from termux_bitnet import BitNetEngine, BitNetConfig

config = BitNetConfig(
    model_path="~/.cache/termux-bitnet/models/bitnet-2b-ggml-model-i2_s.gguf",
    n_threads=8,
    temperature=0.7,
    top_p=0.95,
    top_k=40,
    min_p=0.05,
    repeat_penalty=1.15,
)

with BitNetEngine(config) as engine:
    for token in engine.generate_stream("Write a Python palindrome check:"):
        print(token, end="", flush=True)
```

---

### 3.2 Node.js Gateway (`npm`)

```bash
# 설치
npm install termux-bitnet

# CLI 실행
npx termux-bitnet run -p "Explain harmonic mean in one sentence" -t 8 --temp 0.7 --top-p 0.95
```

```javascript
const { createEngine } = require('termux-bitnet');

async function main() {
  const engine = createEngine({
    threads: 8,
    temperature: 0.7,
    topP: 0.95,
    topK: 40,
    repeatPenalty: 1.15,
  });
  
  await engine.generateStream('Question: Explain harmonic mean:', 128, (token) => {
    process.stdout.write(token);
  });
}

main();
```

---

## 4. 파라미터 매트릭스 (Full Parameter Matrix)

| CLI Flag | Python (`BitNetConfig`) | Node.js (`BitNetOptions`) | C ABI (`bitnet_params_t`) | 기본값 | 설명 |
|---|---|---|---|---|---|
| `-m, --model` | `model_path` | `modelPath` | `model_path` | `""` | GGUF 모델 파일 경로 |
| `-p, --prompt` | `prompt` | `prompt` | `prompt` | `""` | 입력 프롬프트 텍스트 |
| `-t, --threads` | `n_threads` | `threads` | `n_threads` | `cores` | CPU 워커 스레드 수 |
| `-c, --ctx-size` | `n_ctx` | `contextSize` | `n_ctx` | `2048` | KV Cache 컨텍스트 윈도우 크기 |
| `-b, --batch-size`| `n_batch` | `batchSize` | `n_batch` | `512` | 프롬프트 평가 배치 크기 |
| `-n, --n-predict` | `n_predict` | `maxTokens` | `n_predict` | `128` | 최대 생성 토큰 수 |
| `--temp` | `temperature` | `temperature` | `temperature` | `0.7` | Softmax 온도 (0.0=Greedy) |
| `--top-p` | `top_p` | `topP` | `top_p` | `0.95` | Nucleus Top-P 샘플링 |
| `--top-k` | `top_k` | `topK` | `top_k` | `40` | Top-K 샘플링 컷오프 |
| `--min-p` | `min_p` | `minP` | `min_p` | `0.05` | Min-P 상대 확률 컷오프 |
| `--repeat-penalty`| `repeat_penalty` | `repeatPenalty` | `repeat_penalty` | `1.15` | 반복 토큰 억제 계수 |
| `-s, --seed` | `seed` | `seed` | `seed` | `0` | 난수 시드 (0=무작위) |
| `--system-prompt` | `system_prompt` | `systemPrompt` | `system_prompt` | `""` | 시스템 프롬프트 접두사 |
| `-r, --stop` | `stop_tokens` | `stopTokens` | `stop_tokens` | `""` | 생성 중단 토큰 목록 |

---

## 5. C ABI 직접 임베딩 (C/C++)

```c
#include "termux_bitnet.h"
#include <stdio.h>

int main() {
    bitnet_params_t params = bitnet_default_params();
    params.temperature = 0.7f;
    params.top_p = 0.95f;
    params.top_k = 40;
    bitnet_context_t ctx = bitnet_init(&params);

    bitnet_generate_stream(ctx, "The capital of France is", 64, 
        [](const char* token, int32_t id, void* u) {
            printf("%s", token);
            return true;
        }, NULL);

    bitnet_free(ctx);
    return 0;
}
```

---

## 6. 라이선스 (License)

Apache License 2.0. Copyright (c) 2026 uno-km.

